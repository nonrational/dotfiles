AMPScript
====

It is an exact target creation, you can find the docs here: http://wiki.memberlandingpages.com/010_ExactTarget/020_Content/AMPscript/AMPscript_Syntax_Guide

I have some of the syntax hilighting working (code blocks, inline code, "constants"...).

TODO
====
1.  Syntax hilighting in quotes in html attributes
1.  Figure out how to get it into the package control system
1.  Tag Based Syntax
1.  Auto completion of code
1.  Snippets

Patches
====

Submit patches to the .JSON-tmLanguage files, not the xml files which are generated from them.

Build with AAAPackageDev and test against `test.amp`